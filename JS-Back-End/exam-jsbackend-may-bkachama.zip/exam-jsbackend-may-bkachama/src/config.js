module.exports = {
    SECRET: '90184jqhwehjqwehj123lkjqwekjlqej89123' 
};